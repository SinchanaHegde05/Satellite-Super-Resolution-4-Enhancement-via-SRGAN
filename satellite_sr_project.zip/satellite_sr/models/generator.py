"""
Generator Network — RRDB-enhanced Super-Resolution Generator
Inspired by ESRGAN (Enhanced SRGAN) architecture.
"""

import torch
import torch.nn as nn


class ResidualDenseBlock(nn.Module):
    """Residual Dense Block — core building block of RRDB."""

    def __init__(self, in_channels=64, growth_channels=32, bias=True):
        super().__init__()
        C = in_channels
        G = growth_channels

        self.conv1 = nn.Conv2d(C,       G, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(C + G,   G, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(C + 2*G, G, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(C + 3*G, G, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(C + 4*G, C, 3, 1, 1, bias=bias)

        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self.beta  = 0.2   # residual scaling

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, a=0.2)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat([x, x1], 1)))
        x3 = self.lrelu(self.conv3(torch.cat([x, x1, x2], 1)))
        x4 = self.lrelu(self.conv4(torch.cat([x, x1, x2, x3], 1)))
        x5 = self.conv5(torch.cat([x, x1, x2, x3, x4], 1))
        return x5 * self.beta + x


class RRDB(nn.Module):
    """Residual-in-Residual Dense Block."""

    def __init__(self, in_channels=64, growth_channels=32):
        super().__init__()
        self.rdb1 = ResidualDenseBlock(in_channels, growth_channels)
        self.rdb2 = ResidualDenseBlock(in_channels, growth_channels)
        self.rdb3 = ResidualDenseBlock(in_channels, growth_channels)
        self.beta  = 0.2

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return out * self.beta + x


class UpsampleBlock(nn.Module):
    """Pixel-shuffle upsampling block (2x per block)."""

    def __init__(self, channels=64):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels * 4, 3, 1, 1),
            nn.PixelShuffle(2),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class Generator(nn.Module):
    """
    RRDB-based Super-Resolution Generator.

    Architecture:
      Input → Conv → N×RRDB → Conv → Upsample×log2(scale) → Conv → Output
    """

    def __init__(self, in_channels=3, out_channels=3,
                 channels=64, num_res_blocks=16,
                 scale_factor=4, growth_channels=32):
        super().__init__()
        assert scale_factor in (2, 4, 8), "scale_factor must be 2, 4, or 8"

        # Initial feature extraction
        self.conv_first = nn.Conv2d(in_channels, channels, 3, 1, 1)

        # Residual body
        rrdb_blocks = [RRDB(channels, growth_channels) for _ in range(num_res_blocks)]
        self.rrdb_trunk = nn.Sequential(*rrdb_blocks)
        self.conv_trunk = nn.Conv2d(channels, channels, 3, 1, 1)

        # Upsampling — one UpsampleBlock per 2x
        n_upsample = int(torch.log2(torch.tensor(scale_factor)).item())
        self.upsample = nn.Sequential(
            *[UpsampleBlock(channels) for _ in range(n_upsample)]
        )

        # Output head
        self.conv_hr   = nn.Conv2d(channels, channels, 3, 1, 1)
        self.conv_last = nn.Conv2d(channels, out_channels, 3, 1, 1)
        self.lrelu     = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        feat   = self.conv_first(x)
        trunk  = self.conv_trunk(self.rrdb_trunk(feat))
        feat   = feat + trunk                     # global residual
        feat   = self.upsample(feat)
        out    = self.conv_last(self.lrelu(self.conv_hr(feat)))
        return torch.tanh(out)

"""
Discriminator Network — PatchGAN-style discriminator for SRGAN.
Classifies image patches as real/fake rather than the whole image,
which helps enforce local texture realism.
"""

import torch
import torch.nn as nn


class ConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1, use_bn=True):
        super().__init__()
        layers = [nn.Conv2d(in_ch, out_ch, 3, stride, 1, bias=not use_bn)]
        if use_bn:
            layers.append(nn.BatchNorm2d(out_ch))
        layers.append(nn.LeakyReLU(0.2, inplace=True))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class Discriminator(nn.Module):
    """
    VGG-inspired discriminator.

    Input  : (B, 3, H, W)  — HR or SR image
    Output : (B, 1)         — real/fake logit per image
    """

    def __init__(self, in_channels=3, base_channels=64):
        super().__init__()
        C = base_channels

        # Feature extractor (progressively halves spatial dims)
        self.features = nn.Sequential(
            # Block 1 — no BN on first layer (common practice)
            ConvBlock(in_channels, C,      stride=1, use_bn=False),
            ConvBlock(C,           C,      stride=2, use_bn=True),
            # Block 2
            ConvBlock(C,           C * 2,  stride=1, use_bn=True),
            ConvBlock(C * 2,       C * 2,  stride=2, use_bn=True),
            # Block 3
            ConvBlock(C * 2,       C * 4,  stride=1, use_bn=True),
            ConvBlock(C * 4,       C * 4,  stride=2, use_bn=True),
            # Block 4
            ConvBlock(C * 4,       C * 8,  stride=1, use_bn=True),
            ConvBlock(C * 8,       C * 8,  stride=2, use_bn=True),
        )

        # Classifier head
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d(6),          # force 6×6 regardless of input size
            nn.Flatten(),
            nn.Linear(C * 8 * 6 * 6, 1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 1),              # logit (no sigmoid — use BCEWithLogitsLoss)
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.Linear)):
                nn.init.normal_(m.weight, 0.0, 0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        feat = self.features(x)
        return self.classifier(feat)

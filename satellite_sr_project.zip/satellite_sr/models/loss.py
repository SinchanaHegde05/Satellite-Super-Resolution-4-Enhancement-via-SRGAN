"""
Perceptual (VGG Feature) Loss for Super-Resolution.
Compares deep features rather than raw pixels — produces sharper, more
realistic textures than plain MSE/L1 loss.
"""

import torch
import torch.nn as nn
import torchvision.models as models


class PerceptualLoss(nn.Module):
    """
    VGG19-based perceptual loss.
    Uses features from relu3_4 (layer index 22) of a pre-trained VGG19.
    The VGG weights are frozen — only the generator trains against this.
    """

    def __init__(self, feature_layer: int = 22):
        super().__init__()
        vgg = models.vgg19(weights=models.VGG19_Weights.IMAGENET1K_V1)

        # Extract up to the chosen feature layer
        self.feature_extractor = nn.Sequential(
            *list(vgg.features.children())[:feature_layer + 1]
        )

        # Freeze VGG weights — we only use it as a fixed feature extractor
        for param in self.feature_extractor.parameters():
            param.requires_grad = False

        self.feature_extractor.eval()

        # ImageNet normalisation (VGG was trained on these stats)
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std",  torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

        self.criterion = nn.L1Loss()

    def _normalize(self, x: torch.Tensor) -> torch.Tensor:
        """Map from [-1, 1] (tanh output) to ImageNet-normalised range."""
        x = (x + 1.0) / 2.0          # [-1,1] → [0,1]
        return (x - self.mean) / self.std

    def forward(self, sr: torch.Tensor, hr: torch.Tensor) -> torch.Tensor:
        sr_norm = self._normalize(sr)
        hr_norm = self._normalize(hr)

        sr_features = self.feature_extractor(sr_norm)
        hr_features = self.feature_extractor(hr_norm)

        return self.criterion(sr_features, hr_features.detach())

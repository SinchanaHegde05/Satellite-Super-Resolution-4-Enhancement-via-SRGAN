"""
Visualization helpers for Super-Resolution results.
"""

import torch
import torchvision.transforms.functional as TF
from torchvision.utils import make_grid, save_image
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import os


def denormalize(tensor: torch.Tensor) -> torch.Tensor:
    """Convert from [-1, 1] back to [0, 1]."""
    return (tensor + 1.0) / 2.0


def save_comparison_grid(lr: torch.Tensor, sr: torch.Tensor, hr: torch.Tensor,
                         path: str, scale_factor: int = 4,
                         nrow: int = 4) -> None:
    """
    Save a side-by-side comparison grid:
      Row 1: LR (bicubic upscaled for visual comparison)
      Row 2: SR (our output)
      Row 3: HR (ground truth)

    Args:
        lr          : LR input tensors   (B, 3, H/s, W/s)
        sr          : SR output tensors  (B, 3, H, W)
        hr          : HR ground truth    (B, 3, H, W)
        path        : Output file path
        scale_factor: Upscaling factor
        nrow        : Images per row in grid
    """
    n = min(lr.size(0), nrow)

    lr_up = torch.nn.functional.interpolate(
        lr[:n], scale_factor=scale_factor, mode="bicubic", align_corners=False
    )

    lr_grid = make_grid(denormalize(lr_up.clamp(-1, 1)), nrow=n, padding=2)
    sr_grid = make_grid(denormalize(sr[:n].clamp(-1, 1)),  nrow=n, padding=2)
    hr_grid = make_grid(denormalize(hr[:n].clamp(-1, 1)),  nrow=n, padding=2)

    combined = torch.cat([lr_grid, sr_grid, hr_grid], dim=1)  # stack vertically

    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
    save_image(combined, path)


def plot_training_curves(history: dict, save_path: str = "results/training_curves.png") -> None:
    """Save training loss / metric curves using matplotlib."""
    try:
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle("Satellite Super-Resolution — Training Curves", fontsize=16, fontweight="bold")

        metrics = [
            ("gen_loss",  "Generator Loss",     "Loss",   "tab:blue"),
            ("disc_loss", "Discriminator Loss", "Loss",   "tab:red"),
            ("psnr",      "PSNR (dB)",          "dB",     "tab:green"),
            ("ssim",      "SSIM",               "Score",  "tab:purple"),
        ]

        for ax, (key, title, ylabel, color) in zip(axes.flat, metrics):
            if key in history and history[key]:
                epochs = range(1, len(history[key]) + 1)
                ax.plot(epochs, history[key], color=color, linewidth=2)
                ax.set_title(title, fontsize=13)
                ax.set_xlabel("Epoch")
                ax.set_ylabel(ylabel)
                ax.grid(True, alpha=0.3)
                ax.set_facecolor("#f8f9fa")

        plt.tight_layout()
        os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"📊 Training curves saved to {save_path}")

    except ImportError:
        print("matplotlib not installed — skipping curve plot.")

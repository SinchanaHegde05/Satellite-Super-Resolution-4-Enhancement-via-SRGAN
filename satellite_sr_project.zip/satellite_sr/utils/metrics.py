"""
Image Quality Metrics for Super-Resolution evaluation.
  - PSNR  : Peak Signal-to-Noise Ratio  (higher = better, dB)
  - SSIM  : Structural Similarity Index  (higher = better, 0–1)
"""

import torch
import torch.nn.functional as F
import math


def calculate_psnr(sr: torch.Tensor, hr: torch.Tensor,
                   max_val: float = 2.0) -> float:
    """
    PSNR between super-resolved and ground-truth HR images.

    Args:
        sr      : Super-resolution output, range [-1, 1]  (tanh)
        hr      : Ground-truth HR image,   range [-1, 1]
        max_val : Dynamic range (2.0 for [-1,1] tensors)

    Returns:
        PSNR in dB (float)
    """
    with torch.no_grad():
        mse = F.mse_loss(sr, hr)
        if mse == 0:
            return float("inf")
        return 20.0 * math.log10(max_val) - 10.0 * torch.log10(mse).item()


def _gaussian_kernel(kernel_size: int = 11, sigma: float = 1.5,
                     channels: int = 3) -> torch.Tensor:
    """Create a 2-D Gaussian kernel for SSIM computation."""
    coords = torch.arange(kernel_size, dtype=torch.float32) - kernel_size // 2
    g1d    = torch.exp(-(coords ** 2) / (2 * sigma ** 2))
    g2d    = g1d.unsqueeze(0) * g1d.unsqueeze(1)
    g2d   /= g2d.sum()
    return g2d.unsqueeze(0).unsqueeze(0).repeat(channels, 1, 1, 1)


def calculate_ssim(sr: torch.Tensor, hr: torch.Tensor,
                   kernel_size: int = 11, sigma: float = 1.5,
                   data_range: float = 2.0) -> float:
    """
    SSIM between super-resolved and ground-truth HR images.

    Args:
        sr, hr      : Tensors in range [-1, 1], shape (B, C, H, W)
        data_range  : 2.0 for [-1,1] normalised tensors

    Returns:
        Mean SSIM across the batch (float)
    """
    C1 = (0.01 * data_range) ** 2
    C2 = (0.03 * data_range) ** 2

    channels = sr.shape[1]
    kernel   = _gaussian_kernel(kernel_size, sigma, channels).to(sr.device)

    with torch.no_grad():
        mu_sr  = F.conv2d(sr, kernel, padding=kernel_size//2, groups=channels)
        mu_hr  = F.conv2d(hr, kernel, padding=kernel_size//2, groups=channels)

        mu_sr2 = mu_sr ** 2
        mu_hr2 = mu_hr ** 2
        mu_cross = mu_sr * mu_hr

        sigma_sr2  = F.conv2d(sr * sr, kernel, padding=kernel_size//2, groups=channels) - mu_sr2
        sigma_hr2  = F.conv2d(hr * hr, kernel, padding=kernel_size//2, groups=channels) - mu_hr2
        sigma_cross= F.conv2d(sr * hr, kernel, padding=kernel_size//2, groups=channels) - mu_cross

        ssim_map = ((2 * mu_cross  + C1) * (2 * sigma_cross + C2)) / \
                   ((mu_sr2 + mu_hr2 + C1) * (sigma_sr2 + sigma_hr2 + C2))

    return ssim_map.mean().item()

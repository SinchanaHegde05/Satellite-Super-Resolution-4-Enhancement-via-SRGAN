"""
Dataset utilities for Satellite Super-Resolution.

Two modes:
  1. StreamingDataset  — Pulls images directly from HuggingFace datasets hub
                         (UC Merced Land Use, ~2.1k images) without a big download.
                         Each epoch fetches random patches on-the-fly.
  2. SatelliteDataset  — Loads images from a local directory (for custom data).

Dataset Info (UC Merced Land Use Dataset):
  - 2,100 aerial images across 21 land-use categories (agricultural, buildings,
    forest, freeway, harbor, runway, etc.)
  - Each image is 256×256 at 0.3m/pixel ground resolution
  - HuggingFace: https://huggingface.co/datasets/blanchon/UC_Merced
  - Original: http://weegee.vision.ucmerced.edu/datasets/landuse.html
  - Size: ~330 MB total — streamed, so nothing downloads up front
"""

import os
import random
from io import BytesIO
from typing import Optional, Tuple

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

try:
    from datasets import load_dataset   # HuggingFace datasets
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


# ─── Transforms ──────────────────────────────────────────────────────────────

def make_hr_transform(patch_size: int) -> transforms.Compose:
    return transforms.Compose([
        transforms.RandomCrop(patch_size),
        transforms.RandomHorizontalFlip(),
        transforms.RandomVerticalFlip(),
        transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
    ])


def make_lr_transform(patch_size: int, scale_factor: int) -> transforms.Compose:
    lr_size = patch_size // scale_factor
    return transforms.Compose([
        transforms.Resize((lr_size, lr_size), interpolation=Image.BICUBIC),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
    ])


# ─── Paired transform (same crop for HR & LR) ────────────────────────────────

class PairedTransform:
    """Applies identical random crop + flips to both HR and LR images."""

    def __init__(self, patch_size: int, scale_factor: int):
        self.patch_size   = patch_size
        self.scale_factor = scale_factor
        self.lr_size      = patch_size // scale_factor

        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize([0.5]*3, [0.5]*3)

    def __call__(self, pil_img: Image.Image) -> Tuple[torch.Tensor, torch.Tensor]:
        # Ensure image is large enough
        w, h = pil_img.size
        if w < self.patch_size or h < self.patch_size:
            pil_img = pil_img.resize(
                (max(w, self.patch_size), max(h, self.patch_size)),
                Image.BICUBIC
            )
            w, h = pil_img.size

        # Random crop coordinates
        x = random.randint(0, w - self.patch_size)
        y = random.randint(0, h - self.patch_size)
        hr_patch = pil_img.crop((x, y, x + self.patch_size, y + self.patch_size))

        # Random flips
        if random.random() > 0.5:
            hr_patch = hr_patch.transpose(Image.FLIP_LEFT_RIGHT)
        if random.random() > 0.5:
            hr_patch = hr_patch.transpose(Image.FLIP_TOP_BOTTOM)

        # LR = bicubic downscale of HR patch
        lr_patch = hr_patch.resize((self.lr_size, self.lr_size), Image.BICUBIC)

        hr_tensor = self.normalize(self.to_tensor(hr_patch))
        lr_tensor = self.normalize(self.to_tensor(lr_patch))

        return lr_tensor, hr_tensor


# ─── Streaming Dataset (HuggingFace) ─────────────────────────────────────────

class StreamingDataset(Dataset):
    """
    Streams UC Merced Land Use images from HuggingFace without downloading
    the entire dataset. Uses iterable streaming + an in-memory cache.

    Dataset: https://huggingface.co/datasets/blanchon/UC_Merced
    License: Creative Commons (research use)
    """

    def __init__(self, patch_size: int = 96, scale_factor: int = 4,
                 num_samples: int = 1000, split: str = "train"):
        self.transform = PairedTransform(patch_size, scale_factor)
        self.num_samples = num_samples
        self.cache: list[Image.Image] = []

        if not HF_AVAILABLE:
            print("⚠  HuggingFace `datasets` not installed. Using synthetic data.")
            print("   Install with: pip install datasets")
            self._use_synthetic = True
            return

        self._use_synthetic = False
        print("📡 Streaming UC Merced satellite images from HuggingFace…")

        try:
            ds = load_dataset("blanchon/UC_Merced", split=split, streaming=True)
            for i, sample in enumerate(ds):
                if i >= num_samples:
                    break
                img = sample["image"]
                if isinstance(img, Image.Image):
                    self.cache.append(img.convert("RGB"))
                elif hasattr(img, "read"):
                    self.cache.append(Image.open(img).convert("RGB"))

            print(f"   Cached {len(self.cache)} images into memory.")

            if len(self.cache) == 0:
                raise ValueError("No images loaded.")

        except Exception as e:
            print(f"⚠  Could not load HuggingFace dataset: {e}")
            print("   Falling back to synthetic satellite-like patches.")
            self._use_synthetic = True

    def __len__(self) -> int:
        return self.num_samples

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        if self._use_synthetic or len(self.cache) == 0:
            return self._synthetic_sample()

        img = random.choice(self.cache)
        return self.transform(img)

    def _synthetic_sample(self) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate a synthetic satellite-like image patch for testing."""
        size = 256
        arr  = np.zeros((size, size, 3), dtype=np.uint8)

        # Random terrain-like colour blocks
        for _ in range(random.randint(3, 10)):
            x1, y1 = random.randint(0, size-1), random.randint(0, size-1)
            x2, y2 = random.randint(x1, size),  random.randint(y1, size)
            colour = [random.randint(20, 230) for _ in range(3)]
            arr[y1:y2, x1:x2] = colour

        img = Image.fromarray(arr, "RGB")
        transform = PairedTransform(96, 4)
        return transform(img)


# ─── Local Directory Dataset ──────────────────────────────────────────────────

class SatelliteDataset(Dataset):
    """
    Loads satellite images from a local directory.

    Expected structure:
        data/satellite/
            img001.png
            img002.jpg
            ...

    Compatible image sources:
      - UC Merced: http://weegee.vision.ucmerced.edu/datasets/landuse.html
      - DOTA:      https://captain-whu.github.io/DOTA/
      - EuroSAT:   https://github.com/phelber/EuroSAT
      - SpaceNet:  https://spacenet.ai/datasets/
    """

    VALID_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}

    def __init__(self, data_dir: str, patch_size: int = 96,
                 scale_factor: int = 4):
        self.transform = PairedTransform(patch_size, scale_factor)
        self.image_paths = [
            os.path.join(root, f)
            for root, _, files in os.walk(data_dir)
            for f in files
            if os.path.splitext(f)[1].lower() in self.VALID_EXTS
        ]

        if not self.image_paths:
            raise FileNotFoundError(
                f"No images found in '{data_dir}'. "
                "Download a satellite dataset and place images there."
            )

        print(f"📂 Found {len(self.image_paths)} satellite images in {data_dir}")

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        img = Image.open(self.image_paths[idx]).convert("RGB")
        return self.transform(img)
